package com.nec.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan("com.nec.core")
public class TestClient {
	public static void main(String[] args) {
//		Resource resource = new ClassPathResource("springconfig.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);
		
		ApplicationContext context=new AnnotationConfigApplicationContext(TestClient.class);
		Employee emp = (Employee) context.getBean("emp");
		System.out.println(emp);
		
	
	}
}
