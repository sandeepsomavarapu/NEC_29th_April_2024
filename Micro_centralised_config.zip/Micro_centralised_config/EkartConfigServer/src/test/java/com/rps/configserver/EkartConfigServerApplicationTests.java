package com.rps.configserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EkartConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
